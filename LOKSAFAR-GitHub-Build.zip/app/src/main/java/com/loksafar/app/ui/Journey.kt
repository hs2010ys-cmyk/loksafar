@file:OptIn(ExperimentalMaterial3Api::class)

package com.loksafar.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.loksafar.app.R
import com.loksafar.app.data.Achievement
import com.loksafar.app.data.Achievements
import com.loksafar.app.data.Geo
import com.loksafar.app.data.JourneyWithStops
import com.loksafar.app.data.LocalStore
import com.loksafar.app.data.SavedEntity
import com.loksafar.app.data.StampEntity
import com.loksafar.app.data.StopEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import javax.inject.Inject

@HiltViewModel
class JourneyViewModel @Inject constructor(private val local: LocalStore) : ViewModel() {
    private fun <T> kotlinx.coroutines.flow.Flow<T>.hot(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val saved = local.saved.hot(emptyList())
    val journeys = local.journeys.hot(emptyList())
    val stamps = local.stamps.hot(emptyList())
    val achievements = local.stamps.map { Achievements.evaluate(it) }.hot(Achievements.evaluate(emptyList()))

    fun removeSaved(id: String) { viewModelScope.launch { local.removeSaved(id) } }
    fun complete(id: Long) { viewModelScope.launch { local.completeJourney(id) } }
    fun delete(id: Long) { viewModelScope.launch { local.deleteJourney(id) } }

    /** Creates a journey from chosen saved places; optionally reorders stops by straight-line proximity. */
    fun create(title: String, chosen: List<SavedEntity>, orderNearest: Boolean) {
        viewModelScope.launch {
            val dests = chosen.mapNotNull { local.decode(it) }
            val ordered = if (orderNearest) Geo.orderNearest(dests, { it.latitude }, { it.longitude }) else dests
            local.createJourney(title, ordered.map { StopEntity(0, 0, it.id, it.name, it.latitude, it.longitude) })
        }
    }
}

@Composable
fun JourneyScreen(onDestination: (String) -> Unit, vm: JourneyViewModel = hiltViewModel()) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val saved by vm.saved.collectAsStateWithLifecycle()
    val journeys by vm.journeys.collectAsStateWithLifecycle()
    val stamps by vm.stamps.collectAsStateWithLifecycle()
    val achievements by vm.achievements.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(stringResource(R.string.journey_title), Modifier.padding(16.dp), style = MaterialTheme.typography.headlineMedium)
        TabRow(selectedTabIndex = tab) {
            listOf(R.string.tab_saved, R.string.tab_journeys, R.string.tab_passport).forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(stringResource(label), maxLines = 1) })
            }
        }
        when (tab) {
            0 -> SavedTab(saved, onDestination, vm::removeSaved)
            1 -> JourneysTab(saved, journeys, vm::create, vm::complete, vm::delete)
            else -> PassportTab(stamps, achievements)
        }
    }
}

@Composable
private fun SavedTab(saved: List<SavedEntity>, onDestination: (String) -> Unit, onRemove: (String) -> Unit) {
    if (saved.isEmpty()) {
        Text(stringResource(R.string.saved_empty), Modifier.padding(24.dp))
        return
    }
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
        items(saved, key = { it.id }) { s ->
            ListItem(
                headlineContent = { Text(s.name) },
                trailingContent = {
                    IconButton(onClick = { onRemove(s.id) }) { Icon(Icons.Filled.Delete, stringResource(R.string.remove)) }
                },
                modifier = Modifier.clickable { onDestination(s.id) },
            )
        }
    }
}

@Composable
private fun JourneysTab(
    saved: List<SavedEntity>,
    journeys: List<JourneyWithStops>,
    onCreate: (String, List<SavedEntity>, Boolean) -> Unit,
    onComplete: (Long) -> Unit,
    onDelete: (Long) -> Unit,
) {
    var planning by rememberSaveable { mutableStateOf(false) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Button(onClick = { planning = true }, enabled = saved.size >= 2, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.plan_journey))
            }
            if (saved.size < 2) Text(stringResource(R.string.journey_need_saved), Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall)
        }
        if (journeys.isEmpty()) item { Text(stringResource(R.string.journeys_empty)) }
        items(journeys, key = { it.journey.id }) { j -> JourneyCard(j, onComplete, onDelete) }
        if (journeys.isNotEmpty()) item { Text(stringResource(R.string.journey_note), style = MaterialTheme.typography.bodySmall) }
    }
    if (planning) PlanDialog(saved, onDismiss = { planning = false }) { title, chosen, nearest -> onCreate(title, chosen, nearest); planning = false }
}

@Composable
private fun JourneyCard(j: JourneyWithStops, onComplete: (Long) -> Unit, onDelete: (Long) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(j.journey.title, style = MaterialTheme.typography.titleMedium)
            Text(
                stringResource(if (j.completed) R.string.journey_done else R.string.journey_planned) + " · " +
                    stringResource(R.string.journey_stops_count, j.stops.size),
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
            )
            j.stops.forEachIndexed { i, s ->
                if (i > 0) {
                    val p = j.stops[i - 1]
                    Geo.distanceOrNull(p.latitude, p.longitude, s.latitude, s.longitude)?.let {
                        Text(stringResource(R.string.journey_segment, Geo.format(it)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text("${i + 1}. ${s.name}")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!j.completed) TextButton(onClick = { onComplete(j.journey.id) }) { Text(stringResource(R.string.mark_complete)) }
                TextButton(onClick = { onDelete(j.journey.id) }) { Text(stringResource(R.string.delete)) }
            }
        }
    }
}

@Composable
private fun PlanDialog(saved: List<SavedEntity>, onDismiss: () -> Unit, onCreate: (String, List<SavedEntity>, Boolean) -> Unit) {
    var title by rememberSaveable { mutableStateOf("") }
    var nearest by rememberSaveable { mutableStateOf(true) }
    val chosenIds = remember { mutableStateListOf<String>() }  // keeps selection order
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.plan_journey)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text(stringResource(R.string.journey_name)) }, singleLine = true)
                Text(stringResource(R.string.journey_pick_stops), style = MaterialTheme.typography.labelLarge)
                LazyColumn(Modifier.heightIn(max = 240.dp)) {
                    items(saved, key = { it.id }) { s ->
                        val on = s.id in chosenIds
                        Row(
                            Modifier.fillMaxWidth().clickable { if (on) chosenIds.remove(s.id) else chosenIds.add(s.id) },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(checked = on, onCheckedChange = null)
                            Text(s.name, Modifier.padding(start = 8.dp))
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Switch(checked = nearest, onCheckedChange = { nearest = it })
                    Text(stringResource(R.string.journey_order_nearest), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = chosenIds.size >= 2,
                onClick = { onCreate(title.trim(), chosenIds.mapNotNull { id -> saved.firstOrNull { it.id == id } }, nearest) },
            ) { Text(stringResource(R.string.create)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun PassportTab(stamps: List<StampEntity>, achievements: List<Achievement>) {
    val date = remember { DateFormat.getDateInstance(DateFormat.MEDIUM) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(stringResource(R.string.passport_stamps, stamps.size), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.stamp_local_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { SectionTitle(stringResource(R.string.achievements)) }
        items(achievements, key = { it.id }) { a ->
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(stringResource(achievementTitle(a.id)))
                    Text(stringResource(R.string.progress_fmt, a.progress, a.target), style = MaterialTheme.typography.labelLarge, color = if (a.unlocked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
                LinearProgressIndicator(progress = { a.progress.toFloat() / a.target }, modifier = Modifier.fillMaxWidth())
            }
        }
        if (stamps.isEmpty()) item { Text(stringResource(R.string.passport_empty), Modifier.padding(top = 12.dp)) }
        items(stamps, key = { it.destinationId }) { s ->
            ListItem(headlineContent = { Text(s.name) }, supportingContent = { Text(date.format(Date(s.collectedAt))) })
        }
    }
}

private fun achievementTitle(id: String): Int = when (id) {
    "first_stamp" -> R.string.ach_first_stamp
    "stamps_5" -> R.string.ach_stamps_5
    "stamps_15" -> R.string.ach_stamps_15
    "regions_3" -> R.string.ach_regions_3
    else -> R.string.ach_regions_10
}
