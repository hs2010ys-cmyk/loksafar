package com.loksafar.app.data

data class Achievement(val id: String, val progress: Int, val target: Int) {
    val unlocked: Boolean get() = progress >= target
}

/** Achievements are derived from stamps, never stored, so they can't drift out of sync. */
object Achievements {
    fun evaluate(stamps: List<StampEntity>): List<Achievement> {
        val n = stamps.size
        val regions = stamps.mapNotNull { it.stateUtId }.distinct().size
        fun a(id: String, value: Int, target: Int) = Achievement(id, minOf(value, target), target)
        return listOf(
            a("first_stamp", n, 1),
            a("stamps_5", n, 5),
            a("stamps_15", n, 15),
            a("regions_3", regions, 3),
            a("regions_10", regions, 10),
        )
    }
}
