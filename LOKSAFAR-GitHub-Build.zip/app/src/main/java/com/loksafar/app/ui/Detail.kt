@file:OptIn(ExperimentalMaterial3Api::class)

package com.loksafar.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.loksafar.app.R
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.loksafar.app.data.Fix
import com.loksafar.app.data.Geo
import com.loksafar.app.data.LocalStore
import com.loksafar.app.data.StampCheck
import com.loksafar.app.data.StampEntity
import com.loksafar.app.data.StampVerifier
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import com.loksafar.app.data.DestinationDto
import com.loksafar.app.data.RegionPage
import com.loksafar.app.data.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RegionViewModel @Inject constructor(private val repo: Repository, handle: SavedStateHandle) : ViewModel() {
    private val id: String = checkNotNull(handle["id"])
    private val _state = MutableStateFlow<UiState<RegionPage>>(UiState.Loading)
    val state: StateFlow<UiState<RegionPage>> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.value = UiState.Loading
        viewModelScope.launch { _state.value = repo.regionPage(id).toUi() }
    }
}

@HiltViewModel
class CategoryViewModel @Inject constructor(private val repo: Repository, handle: SavedStateHandle) : ViewModel() {
    private val slug: String = checkNotNull(handle["slug"])
    val title: String = Uri.decode(handle.get<String>("name") ?: slug)
    private val _state = MutableStateFlow<UiState<List<DestinationDto>>>(UiState.Loading)
    val state: StateFlow<UiState<List<DestinationDto>>> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.value = UiState.Loading
        viewModelScope.launch { _state.value = repo.categoryDestinations(slug).toUi() }
    }
}

@HiltViewModel
class DestinationViewModel @Inject constructor(
    private val repo: Repository,
    private val local: LocalStore,
    handle: SavedStateHandle,
) : ViewModel() {
    private val id: String = checkNotNull(handle["id"])
    private val _state = MutableStateFlow<UiState<DestinationDto>>(UiState.Loading)
    val state: StateFlow<UiState<DestinationDto>> = _state.asStateFlow()
    val saved: StateFlow<Boolean> = local.isSaved(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    init { load() }

    fun load() {
        _state.value = UiState.Loading
        viewModelScope.launch {
            val result = repo.destination(id)
            _state.value = result.toUi()
            result.getOrNull()?.let { local.recordRecent(it) }
        }
    }

    fun toggleSave(d: DestinationDto) { viewModelScope.launch { local.toggleSaved(d) } }

    /** Verifies a visit on-device and records the stamp if it passes. */
    suspend fun collectStamp(d: DestinationDto, lat: Double, lon: Double, fix: Fix?): StampCheck {
        if (local.hasStamp(d.id)) return StampCheck.AlreadyHave
        val check = StampVerifier.check(lat, lon, fix)
        if (check is StampCheck.Ok) {
            local.addStamp(StampEntity(d.id, d.name, d.stateUtId, System.currentTimeMillis(), check.meters.toInt()))
        }
        return check
    }
}

@Composable
fun RegionScreen(onBack: () -> Unit, onDestination: (DestinationDto) -> Unit, vm: RegionViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    DetailScaffold((state as? UiState.Success)?.data?.region?.name.orEmpty(), onBack) { pad ->
        UiStateView(state, vm::load, Modifier.fillMaxSize().padding(pad)) { page ->
            val r = page.region
            LazyColumn(contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        VerificationChip(r.verificationStatus)
                        Fact(R.string.capital, r.capitals.joinToString { it.display() })
                        Fact(R.string.languages, r.languages.joinToString { it.name })
                        Fact(R.string.tourism, r.tourismIdentity)
                        Fact(R.string.culture, r.culturalIdentity)
                    }
                }
                item { SectionTitle(stringResource(R.string.destinations)) }
                if (page.destinations.isEmpty()) {
                    item { Text(stringResource(R.string.no_destinations), Modifier.padding(horizontal = 16.dp)) }
                }
                items(page.destinations, key = { it.id }) { d -> DestinationRow(d) { onDestination(d) } }
            }
        }
    }
}

@Composable
fun CategoryScreen(onBack: () -> Unit, onDestination: (DestinationDto) -> Unit, vm: CategoryViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    DetailScaffold(vm.title, onBack) { pad ->
        UiStateView(state, vm::load, Modifier.fillMaxSize().padding(pad)) { list ->
            LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                if (list.isEmpty()) item { Text(stringResource(R.string.no_destinations), Modifier.padding(16.dp)) }
                items(list, key = { it.id }) { d -> DestinationRow(d) { onDestination(d) } }
            }
        }
    }
}

@Composable
fun DestinationScreen(onBack: () -> Unit, vm: DestinationViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val saved by vm.saved.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val lang = LocalConfiguration.current.locales[0].language
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<DestinationDto?>(null) }
    val data = (state as? UiState.Success)?.data

    fun attemptStamp(d: DestinationDto) {
        val lat = d.latitude ?: return
        val lon = d.longitude ?: return
        scope.launch {
            busy = true
            val fix = LocationHelper.currentFix(ctx)
            val msg = when (val r = vm.collectStamp(d, lat, lon, fix)) {
                is StampCheck.Ok -> ctx.getString(R.string.stamp_collected, Geo.format(r.meters))
                is StampCheck.TooFar -> ctx.getString(R.string.stamp_too_far, Geo.format(r.meters), StampVerifier.RADIUS_METERS)
                StampCheck.NoLocation -> ctx.getString(R.string.location_unavailable)
                StampCheck.Mocked -> ctx.getString(R.string.stamp_mocked)
                StampCheck.Imprecise -> ctx.getString(R.string.stamp_imprecise)
                StampCheck.AlreadyHave -> ctx.getString(R.string.stamp_have)
            }
            busy = false
            snackbar.showSnackbar(msg)
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val d = pending
        pending = null
        if (d != null) {
            if (grants.values.any { it }) attemptStamp(d)
            else scope.launch { snackbar.showSnackbar(ctx.getString(R.string.stamp_permission_denied)) }
        }
    }

    DetailScaffold(
        title = data?.name.orEmpty(),
        onBack = onBack,
        snackbar = snackbar,
        actions = {
            if (data != null) {
                IconButton(onClick = { vm.toggleSave(data) }) {
                    Icon(
                        if (saved) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = stringResource(if (saved) R.string.saved else R.string.save),
                    )
                }
                IconButton(onClick = {
                    val link = if (data.latitude != null && data.longitude != null)
                        "\nhttps://www.openstreetmap.org/?mlat=${data.latitude}&mlon=${data.longitude}" else ""
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, ctx.getString(R.string.share_text, data.name) + link)
                    ctx.startActivity(Intent.createChooser(send, null))
                }) { Icon(Icons.Filled.Share, contentDescription = stringResource(R.string.share)) }
            }
        },
    ) { pad ->
        UiStateView(state, vm::load, Modifier.fillMaxSize().padding(pad)) { d ->
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                VerificationChip(d.verificationStatus)
                d.localName?.let { Text(it, style = MaterialTheme.typography.titleMedium) }
                d.shortDescription?.let { Text(it) }
                d.detailedDescription?.let { Text(it) }
                Fact(R.string.historical, d.historicalSignificance)
                Fact(R.string.cultural, d.culturalSignificance)
                Fact(R.string.accessibility, d.accessibilityInformation)
                if (listOf(d.shortDescription, d.detailedDescription, d.historicalSignificance, d.culturalSignificance).all { it == null }) {
                    Text(stringResource(R.string.details_pending), style = MaterialTheme.typography.bodyLarge)
                }
                if (d.categories.isNotEmpty()) {
                    d.categories.forEach { c -> AssistChip(onClick = {}, label = { Text(c.labels[lang] ?: c.name) }) }
                }
                val lat = d.latitude
                val lon = d.longitude
                if (lat != null && lon != null) {  // only shown when the backend has coordinates
                    Button(
                        onClick = {
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(${Uri.encode(d.name)})")))
                            } catch (_: ActivityNotFoundException) { /* no maps app installed */ }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.LocationOn, contentDescription = null)
                        Text(stringResource(R.string.open_in_maps), Modifier.padding(start = 8.dp))
                    }
                    OutlinedButton(
                        enabled = !busy,
                        onClick = {
                            if (LocationHelper.hasPermission(ctx)) attemptStamp(d)
                            else { pending = d; permission.launch(LocationHelper.permissions) }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(stringResource(R.string.collect_stamp)) }
                }
            }
        }
    }
}
