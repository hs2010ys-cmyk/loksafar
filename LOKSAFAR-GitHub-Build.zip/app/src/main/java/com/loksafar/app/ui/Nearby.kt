package com.loksafar.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.loksafar.app.R
import com.loksafar.app.data.DestinationDto
import com.loksafar.app.data.Fix
import com.loksafar.app.data.Geo
import com.loksafar.app.data.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NearbyViewModel @Inject constructor(private val repo: Repository) : ViewModel() {
    private val _state = MutableStateFlow<UiState<List<DestinationDto>>>(UiState.Loading)
    val state: StateFlow<UiState<List<DestinationDto>>> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.value = UiState.Loading
        viewModelScope.launch { _state.value = repo.allDestinations().toUi() }
    }
}

@Composable
fun NearbyScreen(onBack: () -> Unit, onBrowse: () -> Unit, onDestination: (DestinationDto) -> Unit, vm: NearbyViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(LocationHelper.hasPermission(ctx)) }
    var fix by remember { mutableStateOf<Fix?>(null) }
    var failed by remember { mutableStateOf(false) }
    var attempt by remember { mutableIntStateOf(0) }  // bump to retry
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = it.values.any { ok -> ok } }

    LaunchedEffect(granted, attempt) {
        if (granted) {
            failed = false
            fix = LocationHelper.currentFix(ctx)
            failed = fix == null
        }
    }

    DetailScaffold(stringResource(R.string.nearby_title), onBack) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            when {
                // Location denied: manual selection stays available (browse by state/UT).
                !granted -> Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.nearby_need_location))
                    Button(onClick = { ask.launch(LocationHelper.permissions) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.allow_location)) }
                    OutlinedButton(onClick = onBrowse, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.browse_by_state)) }
                }
                failed -> Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.location_unavailable))
                    Button(onClick = { fix = null; attempt++ }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.retry)) }
                    OutlinedButton(onClick = onBrowse, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.browse_by_state)) }
                }
                fix == null -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) { CircularProgressIndicator() }
                else -> UiStateView(state, vm::load, Modifier.fillMaxSize()) { all ->
                    val here = fix
                    val ranked = remember(all, here) {
                        if (here == null) emptyList() else all.mapNotNull { d ->
                            val la = d.latitude
                            val lo = d.longitude
                            if (la != null && lo != null) d to Geo.distanceMeters(here.lat, here.lon, la, lo) else null
                        }.sortedBy { it.second }.take(30)
                    }
                    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                        item { Text(stringResource(R.string.nearby_note), Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall) }
                        if (ranked.isEmpty()) item { Text(stringResource(R.string.nearby_none), Modifier.padding(16.dp)) }
                        items(ranked, key = { it.first.id }) { (d, meters) ->
                            ListItem(
                                headlineContent = { Text(d.name) },
                                supportingContent = { Text(stringResource(R.string.distance_away, Geo.format(meters))) },
                                trailingContent = { VerificationChip(d.verificationStatus) },
                                modifier = Modifier.clickable { onDestination(d) },
                            )
                        }
                    }
                }
            }
        }
    }
}
