package com.loksafar.app

import android.app.Application
import com.loksafar.app.data.ThemeMode
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class LoksafarApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ThemeMode.apply(this)
    }
}
