package com.loksafar.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

data class JourneyWithStops(val journey: JourneyEntity, val stops: List<StopEntity>) {
    val completed: Boolean get() = journey.completedAt != null
}

@Serializable private data class ExportSaved(val id: String, val name: String, val savedAt: Long)
@Serializable private data class ExportJourney(val title: String, val createdAt: Long, val completedAt: Long?, val stops: List<String>)
@Serializable private data class ExportStamp(val destinationId: String, val name: String, val collectedAt: Long)
@Serializable private data class ExportBundle(
    val exportedAt: Long, val saved: List<ExportSaved>, val journeys: List<ExportJourney>, val stamps: List<ExportStamp>,
)

/** Everything the user keeps on-device: saved places, recents, journeys and passport stamps. */
@Singleton
class LocalStore @Inject constructor(private val db: AppDatabase, private val json: Json) {
    val saved: Flow<List<SavedEntity>> = db.saved().all()
    val recent: Flow<List<RecentEntity>> = db.recent().latest()
    val stamps: Flow<List<StampEntity>> = db.stamps().all()
    val journeys: Flow<List<JourneyWithStops>> =
        combine(db.journeys().journeys(), db.journeys().allStops()) { js, stops ->
            val byJourney = stops.groupBy { it.journeyId }
            js.map { JourneyWithStops(it, byJourney[it.id].orEmpty().sortedBy { s -> s.position }) }
        }

    fun isSaved(id: String): Flow<Boolean> = db.saved().count(id).map { it > 0 }

    fun decode(e: SavedEntity): DestinationDto? = runCatching { json.decodeFromString<DestinationDto>(e.json) }.getOrNull()
    suspend fun savedDestination(id: String): DestinationDto? = db.saved().get(id)?.let(::decode)

    suspend fun toggleSaved(d: DestinationDto) {
        if (db.saved().get(d.id) != null) db.saved().remove(d.id)
        else db.saved().put(SavedEntity(d.id, d.name, json.encodeToString(d), System.currentTimeMillis()))
    }

    suspend fun removeSaved(id: String) = db.saved().remove(id)

    /** Keeps an already-saved offline copy fresh whenever the network version loads. */
    suspend fun refreshIfSaved(d: DestinationDto) {
        val existing = db.saved().get(d.id) ?: return
        db.saved().put(existing.copy(name = d.name, json = json.encodeToString(d)))
    }

    suspend fun recordRecent(d: DestinationDto) = db.recent().put(RecentEntity(d.id, d.name, System.currentTimeMillis()))

    suspend fun hasStamp(id: String) = db.stamps().count(id) > 0
    suspend fun addStamp(s: StampEntity) = db.stamps().put(s)

    suspend fun createJourney(title: String, stops: List<StopEntity>) =
        db.journeys().create(title.ifBlank { "Journey" }, System.currentTimeMillis(), stops)
    suspend fun completeJourney(id: Long) = db.journeys().complete(id, System.currentTimeMillis())
    suspend fun deleteJourney(id: Long) = db.journeys().delete(id)

    suspend fun clearAll() = withContext(Dispatchers.IO) { db.clearAllTables() }

    suspend fun exportJson(): String {
        val bundle = ExportBundle(
            exportedAt = System.currentTimeMillis(),
            saved = db.saved().all().first().map { ExportSaved(it.id, it.name, it.savedAt) },
            journeys = journeys.first().map { j -> ExportJourney(j.journey.title, j.journey.createdAt, j.journey.completedAt, j.stops.map { it.name }) },
            stamps = db.stamps().all().first().map { ExportStamp(it.destinationId, it.name, it.collectedAt) },
        )
        return Json { prettyPrint = true }.encodeToString(bundle)
    }
}
