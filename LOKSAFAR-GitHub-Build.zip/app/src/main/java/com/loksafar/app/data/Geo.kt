package com.loksafar.app.data

import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Pure geographic helpers. All distances are straight-line (great-circle), never road distances. */
object Geo {
    private const val EARTH_RADIUS_M = 6_371_008.8

    fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dp = Math.toRadians(lat2 - lat1)
        val dl = Math.toRadians(lon2 - lon1)
        val a = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return 2 * EARTH_RADIUS_M * atan2(sqrt(a), sqrt(1 - a))
    }

    fun distanceOrNull(lat1: Double?, lon1: Double?, lat2: Double?, lon2: Double?): Double? =
        if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) null else distanceMeters(lat1, lon1, lat2, lon2)

    /** "350 m" under 1 km, otherwise "12.4 km". */
    fun format(meters: Double, locale: Locale = Locale.getDefault()): String =
        if (meters < 1000) String.format(locale, "%d m", (meters / 10.0).roundToInt() * 10)
        else String.format(locale, "%.1f km", meters / 1000.0)

    /**
     * Greedy nearest-neighbour ordering, starting at the first item that has coordinates.
     * Items without coordinates keep their original relative order and go last.
     * This is a straight-line heuristic, not a routed or optimal itinerary.
     */
    fun <T> orderNearest(items: List<T>, lat: (T) -> Double?, lon: (T) -> Double?): List<T> {
        val (located, unlocated) = items.partition { lat(it) != null && lon(it) != null }
        if (located.size < 2) return located + unlocated
        val remaining = located.toMutableList()
        val result = mutableListOf(remaining.removeAt(0))
        while (remaining.isNotEmpty()) {
            val last = result.last()
            val next = remaining.minBy { distanceMeters(lat(last)!!, lon(last)!!, lat(it)!!, lon(it)!!) }
            remaining.remove(next)
            result.add(next)
        }
        return result + unlocated
    }
}
