@file:OptIn(ExperimentalFoundationApi::class)

package com.loksafar.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.loksafar.app.R
import com.loksafar.app.data.Prefs
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OnboardingViewModel @Inject constructor(private val prefs: Prefs) : ViewModel() {
    suspend fun isOnboarded() = prefs.onboarded.first()
    fun finish(onDone: () -> Unit) { viewModelScope.launch { prefs.setOnboarded(); onDone() } }
}

@Composable
private fun Logo(size: Int) = Image(
    painterResource(R.drawable.logo),
    contentDescription = stringResource(R.string.app_name),
    modifier = Modifier.size(size.dp),
    contentScale = ContentScale.Fit,
)

@Composable
fun SplashScreen(onDone: (onboarded: Boolean) -> Unit, vm: OnboardingViewModel = hiltViewModel()) {
    LaunchedEffect(Unit) { delay(1400); onDone(vm.isOnboarded()) }
    // The logo artwork has a white background, so the splash stays white in dark mode too.
    Column(
        Modifier.fillMaxSize().background(Color.White).systemBarsPadding().padding(32.dp),
        Arrangement.Center, Alignment.CenterHorizontally,
    ) {
        Logo(260)
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.tagline), style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center, color = Color(0xFF0B1F44),
        )
    }
}

@Composable
fun OnboardingScreen(onDone: () -> Unit, vm: OnboardingViewModel = hiltViewModel()) {
    val pager = rememberPagerState { 3 }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp)) {
        HorizontalPager(pager, Modifier.weight(1f)) { page ->
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                when (page) {
                    0 -> {
                        Box(Modifier.clip(MaterialTheme.shapes.large).background(Color.White)) { Logo(200) }
                        Text(stringResource(R.string.onboarding_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Text(stringResource(R.string.onboarding_body), style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                    }
                    1 -> {
                        listOf(R.string.onb_feature_verified, R.string.onb_feature_offline, R.string.onb_feature_ai).forEach {
                            Text(stringResource(it), style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                        }
                    }
                    else -> {
                        Text(stringResource(R.string.choose_language), style = MaterialTheme.typography.titleMedium)
                        LanguagePicker()
                        Text(stringResource(R.string.onb_privacy_title), style = MaterialTheme.typography.titleMedium)
                        Text(stringResource(R.string.onb_privacy_body), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), Arrangement.Center) {
            repeat(3) { i ->
                Box(
                    Modifier.padding(4.dp).size(8.dp).clip(CircleShape)
                        .background(if (pager.currentPage == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                )
            }
        }
        val last = pager.currentPage == 2
        Button(
            onClick = { if (last) vm.finish(onDone) else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
        ) { Text(stringResource(if (last) R.string.continue_guest else R.string.onb_next)) }
    }
}
