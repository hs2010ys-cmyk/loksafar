package com.loksafar.app.ui

import android.net.Uri
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.loksafar.app.R
import com.loksafar.app.data.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

private object Routes {
    const val Splash = "splash"
    const val Onboarding = "onboarding"
    const val Home = "home"
    const val Explore = "explore"
    const val Companion = "companion"
    const val Journey = "journey"
    const val Settings = "settings"
    const val Nearby = "nearby"
    const val Eco = "eco"
    const val Region = "region/{id}"
    const val Destination = "destination/{id}"
    const val Category = "category/{slug}/{name}"
}

@HiltViewModel
class AppViewModel @Inject constructor(repo: Repository) : ViewModel() {
    val offline = repo.offline
}

@Composable
fun LoksafarNav(app: AppViewModel = hiltViewModel()) {
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val offline by app.offline.collectAsStateWithLifecycle()
    val tabs = listOf(
        Triple(Routes.Home, R.string.nav_home, Icons.Filled.Home),
        Triple(Routes.Explore, R.string.nav_explore, Icons.Filled.Place),
        Triple(Routes.Companion, R.string.nav_companion, Icons.Filled.Face),
        Triple(Routes.Journey, R.string.nav_journey, Icons.Filled.Favorite),
        Triple(Routes.Settings, R.string.nav_settings, Icons.Filled.Settings),
    )
    val onTab = tabs.any { it.first == route }
    val goTab = { r: String ->
        nav.navigate(r) { popUpTo(Routes.Home) { saveState = true }; launchSingleTop = true; restoreState = true }
        Unit
    }
    val openDestination = { id: String -> nav.navigate("destination/$id"); Unit }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),  // each screen handles its own insets
        bottomBar = {
            if (onTab) {
                NavigationBar {
                    tabs.forEach { (r, label, icon) ->
                        NavigationBarItem(
                            selected = route == r,
                            onClick = { goTab(r) },
                            icon = { Icon(icon, contentDescription = null) },
                            label = { Text(stringResource(label), maxLines = 1) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).consumeWindowInsets(pad)) {
            NavHost(nav, startDestination = Routes.Splash, modifier = Modifier.weight(1f)) {
                composable(Routes.Splash) {
                    SplashScreen { onboarded ->
                        nav.navigate(if (onboarded) Routes.Home else Routes.Onboarding) { popUpTo(Routes.Splash) { inclusive = true } }
                    }
                }
                composable(Routes.Onboarding) {
                    OnboardingScreen { nav.navigate(Routes.Home) { popUpTo(Routes.Onboarding) { inclusive = true } } }
                }
                composable(Routes.Home) {
                    HomeScreen(
                        onExplore = { goTab(Routes.Explore) },
                        onCompanion = { goTab(Routes.Companion) },
                        onNearby = { nav.navigate(Routes.Nearby) },
                        onEco = { nav.navigate(Routes.Eco) },
                        onCategory = { slug, label -> nav.navigate("category/$slug/${Uri.encode(label)}") },
                        onDestination = openDestination,
                    )
                }
                composable(Routes.Explore) {
                    ExploreScreen(
                        onRegion = { nav.navigate("region/${it.id}") },
                        onDestination = { openDestination(it.id) },
                        onNearby = { nav.navigate(Routes.Nearby) },
                    )
                }
                composable(Routes.Companion) { CompanionScreen() }
                composable(Routes.Journey) { JourneyScreen(onDestination = openDestination) }
                composable(Routes.Settings) { SettingsScreen() }
                composable(Routes.Nearby) {
                    NearbyScreen(onBack = { nav.popBackStack() }, onBrowse = { nav.popBackStack(); goTab(Routes.Explore) }, onDestination = { openDestination(it.id) })
                }
                composable(Routes.Eco) { EcoScreen(onBack = { nav.popBackStack() }, onDestination = { openDestination(it.id) }) }
                composable(Routes.Region) {
                    RegionScreen(onBack = { nav.popBackStack() }, onDestination = { openDestination(it.id) })
                }
                composable(Routes.Category) {
                    CategoryScreen(onBack = { nav.popBackStack() }, onDestination = { openDestination(it.id) })
                }
                composable(Routes.Destination) { DestinationScreen(onBack = { nav.popBackStack() }) }
            }
            if (onTab && offline) {
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        stringResource(R.string.offline_banner),
                        Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
            }
        }
    }
}
