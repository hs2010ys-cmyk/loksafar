@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.loksafar.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.loksafar.app.R
import com.loksafar.app.data.CategoryDto
import com.loksafar.app.data.LocalStore
import com.loksafar.app.data.RecentEntity
import com.loksafar.app.data.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val repo: Repository, local: LocalStore) : ViewModel() {
    private val _categories = MutableStateFlow<UiState<List<CategoryDto>>>(UiState.Loading)
    val categories: StateFlow<UiState<List<CategoryDto>>> = _categories.asStateFlow()
    val recent: StateFlow<List<RecentEntity>> = local.recent.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { load() }

    fun load() {
        _categories.value = UiState.Loading
        viewModelScope.launch { _categories.value = repo.categories().toUi() }
    }
}

@Composable
private fun Shortcut(emoji: String, label: Int, onClick: () -> Unit, modifier: Modifier) {
    ElevatedCard(onClick = onClick, modifier = modifier) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(emoji, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.clearAndSetSemantics { })  // decorative
            Text(stringResource(label), style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun HomeScreen(
    onExplore: () -> Unit,
    onCompanion: () -> Unit,
    onNearby: () -> Unit,
    onEco: () -> Unit,
    onCategory: (slug: String, label: String) -> Unit,
    onDestination: (id: String) -> Unit,
    vm: HomeViewModel = hiltViewModel(),
) {
    val categories by vm.categories.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val lang = LocalConfiguration.current.locales[0].language
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Text(stringResource(R.string.home_discover), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.tagline), style = MaterialTheme.typography.bodyMedium)
        }
        item {
            OutlinedCard(onClick = onExplore, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp).heightIn(min = 32.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Search, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Text(stringResource(R.string.search_hint))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Shortcut("📍", R.string.shortcut_nearby, onNearby, Modifier.weight(1f))
                Shortcut("💬", R.string.shortcut_ask, onCompanion, Modifier.weight(1f))
                Shortcut("🌿", R.string.shortcut_eco, onEco, Modifier.weight(1f))
            }
        }
        if (recent.isNotEmpty()) {
            item { Text(stringResource(R.string.recently_explored), style = MaterialTheme.typography.titleMedium) }
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    recent.forEach { r -> AssistChip(onClick = { onDestination(r.id) }, label = { Text(r.name) }) }
                }
            }
        }
        item { Text(stringResource(R.string.browse_categories), style = MaterialTheme.typography.titleMedium) }
        item {
            UiStateView(categories, vm::load, Modifier.fillMaxWidth()) { list ->
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    list.forEach { c ->
                        val label = c.labels[lang] ?: c.name
                        AssistChip(onClick = { onCategory(c.slug, label) }, label = { Text(label) })
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Info, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Text(stringResource(R.string.verification_note), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
