package com.loksafar.app.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class LanguageDto(
    @SerialName("language_name") val name: String,
    @SerialName("native_name") val nativeName: String? = null,
)

@Serializable
data class CapitalDto(val name: String, val role: String) {
    /** "Srinagar (summer capital)"; plain name for an ordinary capital. */
    fun display() = if (role == "CAPITAL") name else "$name (${role.lowercase().replace('_', ' ')})"
}

@Serializable
data class RegionDto(
    val id: String,
    val name: String,
    val slug: String,
    @SerialName("administrative_type") val type: String,
    @SerialName("cultural_identity") val culturalIdentity: String? = null,
    @SerialName("tourism_identity") val tourismIdentity: String? = null,
    @SerialName("verification_status") val verificationStatus: String,
    val capitals: List<CapitalDto> = emptyList(),
    val languages: List<LanguageDto> = emptyList(),
)

@Serializable
data class CategoryDto(
    val id: String,
    val slug: String,
    val name: String,
    val icon: String? = null,
    val labels: Map<String, String> = emptyMap(),
)

@Serializable
data class DestinationDto(
    val id: String,
    @SerialName("state_ut_id") val stateUtId: String? = null,
    @SerialName("destination_name") val name: String,
    @SerialName("local_name") val localName: String? = null,
    @SerialName("short_description") val shortDescription: String? = null,
    @SerialName("detailed_description") val detailedDescription: String? = null,
    @SerialName("historical_significance") val historicalSignificance: String? = null,
    @SerialName("cultural_significance") val culturalSignificance: String? = null,
    @SerialName("accessibility_information") val accessibilityInformation: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    @SerialName("verification_status") val verificationStatus: String,
    val categories: List<CategoryDto> = emptyList(),
)

@Serializable
data class PageDto<T>(val items: List<T>, val total: Int = 0)

data class RegionPage(val region: RegionDto, val destinations: List<DestinationDto>)

/** Proposed contract for POST /api/v1/ai/chat (not yet verified against a running backend). */
@Serializable
data class ChatRequest(
    val message: String,
    val language: String,
    val mode: String,
    @SerialName("session_id") val sessionId: String? = null,
)

@Serializable
data class SourceDto(val title: String, val url: String? = null)

@Serializable
data class ChatResponse(
    val answer: String,
    val sources: List<SourceDto> = emptyList(),
    val confidence: String? = null,
    val warnings: List<String> = emptyList(),
    @SerialName("session_id") val sessionId: String? = null,
)
