package com.loksafar.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Brand palette taken from the LOKSAFAR logo: saffron, navy and India-green.
private val Light = lightColorScheme(
    primary = Color(0xFFB8470A), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDBC8), onPrimaryContainer = Color(0xFF3A1200),
    secondary = Color(0xFF14305F), onSecondary = Color.White,
    secondaryContainer = Color(0xFFD9E2FF), onSecondaryContainer = Color(0xFF001945),
    tertiary = Color(0xFF1B6B1A), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFB9F2A8), onTertiaryContainer = Color(0xFF002200),
)
private val Dark = darkColorScheme(
    primary = Color(0xFFFFB68F), onPrimary = Color(0xFF561F00),
    primaryContainer = Color(0xFF7C2F00), onPrimaryContainer = Color(0xFFFFDBC8),
    secondary = Color(0xFFB0C6FF), onSecondary = Color(0xFF002D6E),
    secondaryContainer = Color(0xFF1B3F7A), onSecondaryContainer = Color(0xFFD9E2FF),
    tertiary = Color(0xFF9DD68D), onTertiary = Color(0xFF053900),
    tertiaryContainer = Color(0xFF235015), onTertiaryContainer = Color(0xFFB9F2A8),
)

/** Follows the (possibly app-overridden) night mode; see ThemeMode in data/Prefs.kt. */
@Composable
fun LoksafarTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
