package com.loksafar.app.ui

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.loksafar.app.BuildConfig
import com.loksafar.app.R
import com.loksafar.app.data.LocalStore
import com.loksafar.app.data.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(val local: LocalStore) : ViewModel()

@Composable
fun SettingsScreen(vm: SettingsViewModel = hiltViewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var theme by remember { mutableStateOf(ThemeMode.get(ctx)) }
    var confirmDelete by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(stringResource(R.string.nav_settings), style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })

        Text(stringResource(R.string.language), style = MaterialTheme.typography.titleMedium)
        LanguagePicker()

        Text(stringResource(R.string.theme), style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(ThemeMode.SYSTEM to R.string.theme_system, ThemeMode.LIGHT to R.string.theme_light, ThemeMode.DARK to R.string.theme_dark)
                .forEach { (mode, label) ->
                    FilterChip(
                        selected = theme == mode,
                        onClick = { theme = mode; ThemeMode.set(ctx, mode) },  // recreates the activity to apply
                        label = { Text(stringResource(label)) },
                    )
                }
        }

        Text(stringResource(R.string.privacy_data), style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
        Text(stringResource(R.string.privacy_body), style = MaterialTheme.typography.bodyMedium)
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    val send = Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_TEXT, vm.local.exportJson())
                    ctx.startActivity(Intent.createChooser(send, null))
                }
            },
        ) { Text(stringResource(R.string.export_data)) }
        OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { confirmDelete = true }) { Text(stringResource(R.string.delete_data)) }

        Text(stringResource(R.string.verification_note), style = MaterialTheme.typography.bodyMedium)
        Text("v${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.labelMedium)
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.delete_data)) },
            text = { Text(stringResource(R.string.delete_data_confirm)) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; scope.launch { vm.local.clearAll() } }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
