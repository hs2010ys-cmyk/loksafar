package com.loksafar.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.KSerializer
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

private suspend fun <T> safe(block: suspend () -> T): Result<T> =
    try { Result.success(block()) } catch (e: CancellationException) { throw e } catch (e: Exception) { Result.failure(e) }

@Singleton
class Repository @Inject constructor(
    private val api: LoksafarApi,
    private val db: AppDatabase,
    private val local: LocalStore,
    private val json: Json,
) {
    private val _offline = MutableStateFlow(false)
    /** True when the last directory load had to fall back to a saved copy. */
    val offline: StateFlow<Boolean> = _offline.asStateFlow()

    /** Network first; on failure fall back to the last good copy so the directory works offline. */
    private suspend fun <T> cached(key: String, ser: KSerializer<T>, fetch: suspend () -> T): Result<T> {
        val net = safe(fetch)
        if (net.isSuccess) {
            _offline.value = false
            net.getOrNull()?.let { db.cache().put(CacheEntity(key, json.encodeToString(ser, it), System.currentTimeMillis())) }
            return net
        }
        val hit = db.cache().get(key)?.let { runCatching { json.decodeFromString(ser, it.json) }.getOrNull() }
        return if (hit != null) { _offline.value = true; Result.success(hit) } else net
    }

    suspend fun regions() = cached("regions", ListSerializer(RegionDto.serializer())) {
        coroutineScope {
            val states = async { api.states() }
            val uts = async { api.unionTerritories() }
            states.await() + uts.await()
        }
    }

    suspend fun categories() = cached("categories", ListSerializer(CategoryDto.serializer())) { api.categories() }
    suspend fun searchDestinations(q: String) = safe { api.destinations(q = q).items }
    suspend fun categoryDestinations(slug: String) = safe { api.destinations(category = slug).items }
    suspend fun allDestinations() = safe { api.destinations().items }

    /** Eco-tourism category is looked up by slug so a renamed backend slug doesn't break the screen. */
    suspend fun ecoDestinations() = safe {
        val cat = api.categories().firstOrNull { it.slug.contains("eco", ignoreCase = true) }
        if (cat == null) emptyList() else api.destinations(category = cat.slug).items
    }

    /** Falls back to the user's saved offline copy when the network fails. */
    suspend fun destination(id: String): Result<DestinationDto> {
        val net = safe { api.destination(id) }
        net.getOrNull()?.let { local.refreshIfSaved(it); return net }
        return local.savedDestination(id)?.let { Result.success(it) } ?: net
    }

    suspend fun regionPage(id: String) = safe {
        coroutineScope {
            val region = async { api.region(id) }
            val dests = async { api.destinations(stateId = id) }
            RegionPage(region.await(), dests.await().items)
        }
    }

    suspend fun chat(request: ChatRequest) = safe { api.chat(request) }
}
