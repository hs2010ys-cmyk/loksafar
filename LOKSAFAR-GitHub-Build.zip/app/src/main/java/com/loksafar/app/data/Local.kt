package com.loksafar.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

/** A destination the user saved; [json] holds the full DestinationDto so it can be read offline. */
@Entity(tableName = "saved")
data class SavedEntity(@PrimaryKey val id: String, val name: String, val json: String, val savedAt: Long)

@Entity(tableName = "recent")
data class RecentEntity(@PrimaryKey val id: String, val name: String, val viewedAt: Long)

@Entity(tableName = "journeys")
data class JourneyEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val createdAt: Long, val completedAt: Long? = null)

@Entity(
    tableName = "journey_stops",
    primaryKeys = ["journeyId", "position"],
    foreignKeys = [ForeignKey(JourneyEntity::class, ["id"], ["journeyId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("journeyId")],
)
data class StopEntity(
    val journeyId: Long, val position: Int, val destinationId: String, val name: String,
    val latitude: Double?, val longitude: Double?,
)

@Entity(tableName = "stamps")
data class StampEntity(
    @PrimaryKey val destinationId: String, val name: String, val stateUtId: String?,
    val collectedAt: Long, val distanceMeters: Int,
)

/** Last successful API response per key (regions, categories) so the directory works offline. */
@Entity(tableName = "api_cache")
data class CacheEntity(@PrimaryKey val key: String, val json: String, val updatedAt: Long)

@Dao
interface SavedDao {
    @Query("SELECT * FROM saved ORDER BY savedAt DESC") fun all(): Flow<List<SavedEntity>>
    @Query("SELECT COUNT(*) FROM saved WHERE id = :id") fun count(id: String): Flow<Int>
    @Query("SELECT * FROM saved WHERE id = :id") suspend fun get(id: String): SavedEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(e: SavedEntity)
    @Query("DELETE FROM saved WHERE id = :id") suspend fun remove(id: String)
}

@Dao
interface RecentDao {
    @Query("SELECT * FROM recent ORDER BY viewedAt DESC LIMIT 10") fun latest(): Flow<List<RecentEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(e: RecentEntity)
}

@Dao
abstract class JourneyDao {
    @Query("SELECT * FROM journeys ORDER BY createdAt DESC") abstract fun journeys(): Flow<List<JourneyEntity>>
    @Query("SELECT * FROM journey_stops ORDER BY journeyId, position") abstract fun allStops(): Flow<List<StopEntity>>
    @Insert abstract suspend fun insertJourney(j: JourneyEntity): Long
    @Insert abstract suspend fun insertStops(s: List<StopEntity>)
    @Query("UPDATE journeys SET completedAt = :at WHERE id = :id") abstract suspend fun complete(id: Long, at: Long)
    @Query("DELETE FROM journeys WHERE id = :id") abstract suspend fun delete(id: Long)

    /** Journey and its stops are written atomically. */
    @Transaction
    open suspend fun create(title: String, now: Long, stops: List<StopEntity>) {
        val id = insertJourney(JourneyEntity(title = title, createdAt = now))
        insertStops(stops.mapIndexed { i, s -> s.copy(journeyId = id, position = i) })
    }
}

@Dao
interface StampDao {
    @Query("SELECT * FROM stamps ORDER BY collectedAt DESC") fun all(): Flow<List<StampEntity>>
    @Query("SELECT COUNT(*) FROM stamps WHERE destinationId = :id") suspend fun count(id: String): Int
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun put(e: StampEntity)
}

@Dao
interface CacheDao {
    @Query("SELECT * FROM api_cache WHERE `key` = :key") suspend fun get(key: String): CacheEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(e: CacheEntity)
}

@Database(
    entities = [SavedEntity::class, RecentEntity::class, JourneyEntity::class, StopEntity::class, StampEntity::class, CacheEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun saved(): SavedDao
    abstract fun recent(): RecentDao
    abstract fun journeys(): JourneyDao
    abstract fun stamps(): StampDao
    abstract fun cache(): CacheDao
}
