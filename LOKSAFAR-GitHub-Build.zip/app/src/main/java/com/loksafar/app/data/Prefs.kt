package com.loksafar.app.data

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsStore by preferencesDataStore(name = "settings")

@Singleton
class Prefs @Inject constructor(@ApplicationContext private val context: Context) {
    private val onboardedKey = booleanPreferencesKey("onboarded")
    val onboarded: Flow<Boolean> = context.settingsStore.data.map { it[onboardedKey] ?: false }
    suspend fun setOnboarded() { context.settingsStore.edit { it[onboardedKey] = true } }
}

/**
 * Light/dark choice. Kept in SharedPreferences (not DataStore) because it must be applied
 * synchronously in Application.onCreate, before the first frame, to avoid a theme flash.
 */
object ThemeMode {
    const val SYSTEM = "system"
    const val LIGHT = "light"
    const val DARK = "dark"
    private const val FILE = "ui"
    private const val KEY = "theme_mode"

    fun get(context: Context): String = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, SYSTEM) ?: SYSTEM

    fun apply(context: Context) = AppCompatDelegate.setDefaultNightMode(
        when (get(context)) {
            LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
            DARK -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        },
    )

    fun set(context: Context, mode: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, mode).apply()
        apply(context)
    }
}
