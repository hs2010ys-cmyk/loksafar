package com.loksafar.app.data

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface LoksafarApi {
    @GET("api/v1/india/states") suspend fun states(): List<RegionDto>
    @GET("api/v1/india/union-territories") suspend fun unionTerritories(): List<RegionDto>
    @GET("api/v1/states/{id}") suspend fun region(@Path("id") id: String): RegionDto
    @GET("api/v1/categories") suspend fun categories(): List<CategoryDto>
    @GET("api/v1/destinations") suspend fun destinations(
        @Query("state_id") stateId: String? = null,
        @Query("category") category: String? = null,
        @Query("q") q: String? = null,
        @Query("page_size") pageSize: Int = 100,
    ): PageDto<DestinationDto>
    @GET("api/v1/destinations/{id}") suspend fun destination(@Path("id") id: String): DestinationDto
    @POST("api/v1/ai/chat") suspend fun chat(@Body request: ChatRequest): ChatResponse
}
