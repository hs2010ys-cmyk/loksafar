package com.loksafar.app.data

/** A location reading, reduced to what verification needs (keeps the logic free of Android types). */
data class Fix(val lat: Double, val lon: Double, val accuracyMeters: Float?, val isMock: Boolean)

sealed interface StampCheck {
    data class Ok(val meters: Double) : StampCheck
    data class TooFar(val meters: Double) : StampCheck
    data object NoLocation : StampCheck
    data object Mocked : StampCheck
    data object Imprecise : StampCheck
    data object AlreadyHave : StampCheck
}

/**
 * On-device visit check for Heritage Passport stamps.
 * This is a first line of defence only: a determined user can defeat client-side checks,
 * so stamps must be re-verified server-side before they count toward certificates or rewards.
 */
object StampVerifier {
    const val RADIUS_METERS = 500
    const val MAX_ACCURACY_METERS = 150f

    fun check(destLat: Double, destLon: Double, fix: Fix?): StampCheck {
        if (fix == null) return StampCheck.NoLocation
        if (fix.isMock) return StampCheck.Mocked
        val acc = fix.accuracyMeters
        if (acc == null || acc > MAX_ACCURACY_METERS) return StampCheck.Imprecise
        val d = Geo.distanceMeters(fix.lat, fix.lon, destLat, destLon)
        return if (d <= RADIUS_METERS) StampCheck.Ok(d) else StampCheck.TooFar(d)
    }
}
