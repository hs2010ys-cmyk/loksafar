@file:OptIn(ExperimentalMaterial3Api::class)

package com.loksafar.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.loksafar.app.R
import com.loksafar.app.data.DestinationDto
import com.loksafar.app.data.RegionDto
import com.loksafar.app.data.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ExploreViewModel @Inject constructor(private val repo: Repository) : ViewModel() {
    private val _regions = MutableStateFlow<UiState<List<RegionDto>>>(UiState.Loading)
    val regions: StateFlow<UiState<List<RegionDto>>> = _regions.asStateFlow()
    val query = MutableStateFlow("")

    /** Destination matches from the backend once the query has 2+ characters. */
    @OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
    val hits: StateFlow<List<DestinationDto>> = query
        .debounce(300)
        .mapLatest { q -> if (q.trim().length < 2) emptyList() else repo.searchDestinations(q.trim()).getOrDefault(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { load() }

    fun load() {
        _regions.value = UiState.Loading
        viewModelScope.launch { _regions.value = repo.regions().toUi() }
    }
}

private fun RegionDto.matches(q: String) =
    name.contains(q, true) || capitals.any { it.name.contains(q, true) } || languages.any { it.name.contains(q, true) }

@Composable
fun ExploreScreen(onRegion: (RegionDto) -> Unit, onDestination: (DestinationDto) -> Unit, onNearby: () -> Unit, vm: ExploreViewModel = hiltViewModel()) {
    val regions by vm.regions.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val hits by vm.hits.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }  // 0 all, 1 states, 2 UTs

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        OutlinedTextField(
            value = query,
            onValueChange = { vm.query.value = it },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            placeholder = { Text(stringResource(R.string.search_hint)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(R.string.all, R.string.states, R.string.union_territories).forEachIndexed { i, label ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(stringResource(label)) })
            }
            AssistChip(onClick = onNearby, label = { Text(stringResource(R.string.places_near_me)) })
        }
        UiStateView(regions, vm::load, Modifier.fillMaxSize()) { all ->
            val q = query.trim()
            val shown = remember(all, q, tab) {
                all.filter {
                    (tab == 0 || (tab == 1 && it.type == "STATE") || (tab == 2 && it.type == "UNION_TERRITORY")) &&
                        (q.isEmpty() || it.matches(q))
                }
            }
            LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                if (hits.isNotEmpty()) {
                    item { SectionTitle(stringResource(R.string.destinations)) }
                    items(hits, key = { it.id }) { d -> DestinationRow(d) { onDestination(d) } }
                }
                items(shown, key = { it.id }) { r ->
                    ListItem(
                        headlineContent = { Text(r.name) },
                        supportingContent = { Text("${stringResource(R.string.capital)}: ${r.capitals.joinToString { it.display() }}") },
                        modifier = Modifier.clickable { onRegion(r) },
                    )
                }
            }
        }
    }
}
