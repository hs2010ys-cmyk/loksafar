@file:OptIn(ExperimentalMaterial3Api::class)

package com.loksafar.app.ui

import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import com.loksafar.app.R
import com.loksafar.app.data.DestinationDto

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Error(val message: String) : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
}

fun <T> Result<T>.toUi(): UiState<T> =
    fold({ UiState.Success(it) }, { UiState.Error(it.message.orEmpty()) })

@Composable
fun <T> UiStateView(state: UiState<T>, onRetry: () -> Unit, modifier: Modifier = Modifier, content: @Composable (T) -> Unit) {
    when (state) {
        UiState.Loading -> Box(modifier.padding(24.dp), Alignment.Center) { CircularProgressIndicator() }
        is UiState.Error -> Column(modifier.padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text(stringResource(R.string.error_generic), textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onRetry) { Text(stringResource(R.string.retry)) }
        }
        is UiState.Success -> content(state.data)
    }
}

/** Shows how trustworthy a piece of data is. Anything not VERIFIED is labelled, never presented as fact. */
@Composable
fun VerificationChip(status: String) {
    val c = MaterialTheme.colorScheme
    val (label, bg, fg) = when (status) {
        "VERIFIED" -> Triple(R.string.status_verified, c.tertiaryContainer, c.onTertiaryContainer)
        "OUTDATED" -> Triple(R.string.status_outdated, c.errorContainer, c.onErrorContainer)
        "NEEDS_REVIEW", "REJECTED" -> Triple(R.string.status_review, c.errorContainer, c.onErrorContainer)
        else -> Triple(R.string.status_pending, c.surfaceVariant, c.onSurfaceVariant)
    }
    Surface(color = bg, contentColor = fg, shape = MaterialTheme.shapes.small) {
        Text(stringResource(label), Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun SectionTitle(text: String) =
    Text(text, Modifier.padding(horizontal = 16.dp, vertical = 8.dp).semantics { heading() }, style = MaterialTheme.typography.titleMedium)

@Composable
fun Fact(@StringRes label: Int, value: String?) {
    if (value.isNullOrBlank()) return
    Column {
        Text(stringResource(label), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun DestinationRow(d: DestinationDto, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(d.name) },
        supportingContent = d.localName?.let { t -> @Composable { Text(t) } },
        trailingContent = { VerificationChip(d.verificationStatus) },
        modifier = Modifier.clickable(onClick = onClick),
    )
}

@Composable
fun DetailScaffold(
    title: String,
    onBack: () -> Unit,
    snackbar: SnackbarHostState? = null,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        snackbarHost = { snackbar?.let { SnackbarHost(it) } },
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
                },
                actions = actions,
            )
        },
        content = content,
    )
}

/** Switches the whole app between English and Hindi (per-app locale; persists across restarts). */
@Composable
fun LanguagePicker() {
    val current = LocalConfiguration.current.locales[0].language
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("en" to "English", "hi" to "हिन्दी").forEach { (code, label) ->
            FilterChip(
                selected = current == code,
                onClick = { AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code)) },
                label = { Text(label) },
            )
        }
    }
}

/** clickable() that also exposes a link role to screen readers. */
fun Modifier.clickableSafely(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(role = androidx.compose.ui.semantics.Role.Button, onClick = onClick))
