package com.loksafar.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.loksafar.app.ui.LoksafarNav
import com.loksafar.app.ui.LoksafarTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {  // AppCompat enables per-app language switching (en/hi)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LoksafarTheme { LoksafarNav() } }
    }
}
