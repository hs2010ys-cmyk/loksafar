package com.loksafar.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.loksafar.app.R
import com.loksafar.app.data.DestinationDto
import com.loksafar.app.data.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EcoViewModel @Inject constructor(private val repo: Repository) : ViewModel() {
    private val _state = MutableStateFlow<UiState<List<DestinationDto>>>(UiState.Loading)
    val state: StateFlow<UiState<List<DestinationDto>>> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.value = UiState.Loading
        viewModelScope.launch { _state.value = repo.ecoDestinations().toUi() }
    }
}

private val tips = listOf(
    R.string.eco_tip_1, R.string.eco_tip_2, R.string.eco_tip_3, R.string.eco_tip_4,
    R.string.eco_tip_5, R.string.eco_tip_6, R.string.eco_tip_7,
)

/** General responsible-travel guidance (static) plus eco-tourism places from the backend (verified labels apply). */
@Composable
fun EcoScreen(onBack: () -> Unit, onDestination: (DestinationDto) -> Unit, vm: EcoViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    DetailScaffold(stringResource(R.string.eco_title), onBack) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(vertical = 8.dp)) {
            item { SectionTitle(stringResource(R.string.eco_guidance)) }
            items(tips) { Text("•  " + stringResource(it), Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodyLarge) }
            item { SectionTitle(stringResource(R.string.eco_places)) }
            item {
                UiStateView(state, vm::load) { list ->
                    androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                        if (list.isEmpty()) Text(stringResource(R.string.no_destinations), Modifier.padding(16.dp))
                        list.forEach { d -> DestinationRow(d) { onDestination(d) } }
                    }
                }
            }
        }
    }
}
