@file:OptIn(ExperimentalMaterial3Api::class)

package com.loksafar.app.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.loksafar.app.R
import com.loksafar.app.data.ChatRequest
import com.loksafar.app.data.Repository
import com.loksafar.app.data.SourceDto
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChatMsg(
    val fromUser: Boolean,
    val text: String = "",
    val sources: List<SourceDto> = emptyList(),
    val confidence: String? = null,
    val warnings: List<String> = emptyList(),
    val error: Boolean = false,
)

/** Chat modes sent to the backend as "explorer" | "historian" | "storyteller". */
enum class ChatMode(val wire: String, val label: Int) {
    EXPLORER("explorer", R.string.mode_explorer),
    HISTORIAN("historian", R.string.mode_historian),
    STORYTELLER("storyteller", R.string.mode_storyteller),
}

@HiltViewModel
class CompanionViewModel @Inject constructor(private val repo: Repository) : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val messages: StateFlow<List<ChatMsg>> = _messages.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _mode = MutableStateFlow(ChatMode.EXPLORER)
    val mode: StateFlow<ChatMode> = _mode.asStateFlow()
    private var sessionId: String? = null  // lets the backend keep conversation context

    fun setMode(m: ChatMode) { _mode.value = m }

    fun reset() { _messages.value = emptyList(); sessionId = null }

    fun send(text: String, language: String) {
        val q = text.trim()
        if (q.isEmpty() || _busy.value) return
        _messages.update { it + ChatMsg(fromUser = true, text = q) }
        _busy.value = true
        viewModelScope.launch {
            repo.chat(ChatRequest(q, language, _mode.value.wire, sessionId)).fold(
                onSuccess = { r ->
                    sessionId = r.sessionId ?: sessionId
                    _messages.update { it + ChatMsg(false, r.answer, r.sources, r.confidence, r.warnings) }
                },
                // No local guessing: if the backend can't answer, we say so instead of inventing an answer.
                onFailure = { _messages.update { it + ChatMsg(false, error = true) } },
            )
            _busy.value = false
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val c = MaterialTheme.colorScheme
    val uri = LocalUriHandler.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = when { m.fromUser -> c.primaryContainer; m.error -> c.errorContainer; else -> c.surfaceVariant },
            contentColor = when { m.fromUser -> c.onPrimaryContainer; m.error -> c.onErrorContainer; else -> c.onSurfaceVariant },
            shape = MaterialTheme.shapes.large,
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (m.error) stringResource(R.string.companion_unavailable) else m.text)
                m.warnings.forEach { Text(it, style = MaterialTheme.typography.labelMedium, color = c.error) }
                m.confidence?.let { Text(stringResource(R.string.companion_confidence, it), style = MaterialTheme.typography.labelMedium) }
                if (m.sources.isNotEmpty()) {
                    Text(stringResource(R.string.companion_sources), style = MaterialTheme.typography.labelLarge, modifier = Modifier.semantics { heading() })
                    m.sources.forEach { s ->
                        val link = s.url
                        Text(
                            s.title,
                            style = MaterialTheme.typography.bodySmall,
                            textDecoration = if (link != null) TextDecoration.Underline else null,
                            modifier = if (link != null) Modifier.clickableSafely { runCatching { uri.openUri(link) } } else Modifier,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CompanionScreen(vm: CompanionViewModel = hiltViewModel()) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val lang = LocalConfiguration.current.locales[0].language
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val spoken = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && spoken != null) input = spoken
    }
    LaunchedEffect(messages.size, busy) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size + if (busy) 1 else 0) }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(Modifier.padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.companion_title), style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.weight(1f).semantics { heading() },
            )
            IconButton(onClick = vm::reset) { Icon(Icons.Filled.Refresh, stringResource(R.string.companion_new)) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChatMode.entries.forEach { m ->
                FilterChip(selected = mode == m, onClick = { vm.setMode(m) }, label = { Text(stringResource(m.label)) })
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = listState,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { Text(stringResource(R.string.companion_intro), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(messages) { Bubble(it) }
            if (busy) item { Text(stringResource(R.string.companion_thinking), style = MaterialTheme.typography.labelLarge) }
        }
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.companion_hint)) }, maxLines = 4,
            )
            IconButton(onClick = {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == "hi") "hi-IN" else "en-IN")
                try { speech.launch(intent) } catch (_: ActivityNotFoundException) {
                    Toast.makeText(ctx, R.string.companion_voice_unavailable, Toast.LENGTH_SHORT).show()
                }
            }) { Text("🎤", modifier = Modifier.semantics { contentDescription = ctx.getString(R.string.companion_voice) }) }
            IconButton(enabled = input.isNotBlank() && !busy, onClick = { vm.send(input, lang); input = "" }) {
                Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.companion_send))
            }
        }
    }
}
