package com.loksafar.app

import com.loksafar.app.data.Achievements
import com.loksafar.app.data.Fix
import com.loksafar.app.data.Geo
import com.loksafar.app.data.StampCheck
import com.loksafar.app.data.StampEntity
import com.loksafar.app.data.StampVerifier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class GeoTest {
    @Test fun samePointIsZero() = assertEquals(0.0, Geo.distanceMeters(28.6, 77.2, 28.6, 77.2), 0.0)

    @Test fun delhiToMumbaiIsAbout1148Km() =
        assertEquals(1148.0, Geo.distanceMeters(28.6139, 77.2090, 19.0760, 72.8777) / 1000, 8.0)

    @Test fun oneDegreeOfLatitude() = assertEquals(111.19, Geo.distanceMeters(0.0, 0.0, 1.0, 0.0) / 1000, 0.2)

    @Test fun nullCoordinatesGiveNull() = assertNull(Geo.distanceOrNull(null, 1.0, 2.0, 3.0))

    @Test fun formatsMetersAndKilometres() {
        assertEquals("350 m", Geo.format(349.0, Locale.ROOT))
        assertEquals("12.4 km", Geo.format(12_400.0, Locale.ROOT))
    }

    private data class P(val n: String, val la: Double?, val lo: Double?)

    @Test fun ordersByNearestNeighbourAndKeepsUnlocatedLast() {
        val pts = listOf(P("A", 0.0, 0.0), P("D", 0.0, 3.0), P("B", 0.0, 1.0), P("X", null, null), P("C", 0.0, 2.0))
        assertEquals(listOf("A", "B", "C", "D", "X"), Geo.orderNearest(pts, { it.la }, { it.lo }).map { it.n })
    }
}

class StampVerifierTest {
    private val lat = 28.6562
    private val lon = 77.2410
    private fun fix(dLat: Double = 0.0, acc: Float? = 20f, mock: Boolean = false) = Fix(lat + dLat, lon, acc, mock)

    @Test fun noFix() = assertTrue(StampVerifier.check(lat, lon, null) is StampCheck.NoLocation)
    @Test fun mockLocationRejectedEvenWhenFarAway() = assertTrue(StampVerifier.check(lat, lon, fix(dLat = 1.0, mock = true)) is StampCheck.Mocked)
    @Test fun unknownOrPoorAccuracyRejected() {
        assertTrue(StampVerifier.check(lat, lon, fix(acc = null)) is StampCheck.Imprecise)
        assertTrue(StampVerifier.check(lat, lon, fix(acc = 151f)) is StampCheck.Imprecise)
    }
    @Test fun withinRadiusAccepted() = assertTrue(StampVerifier.check(lat, lon, fix(dLat = 0.002)) is StampCheck.Ok)
    @Test fun outsideRadiusRejected() = assertTrue(StampVerifier.check(lat, lon, fix(dLat = 0.005)) is StampCheck.TooFar)
}

class AchievementsTest {
    private fun stamp(i: Int, region: String?) = StampEntity("d$i", "n$i", region, 0, 10)

    @Test fun nothingUnlockedWithoutStamps() = assertTrue(Achievements.evaluate(emptyList()).none { it.unlocked })

    @Test fun regionsCountDistinctRegionsOnly() {
        val six = Achievements.evaluate((1..6).map { stamp(it, "a") })
        assertTrue(six.first { it.id == "stamps_5" }.unlocked)
        assertFalse(six.first { it.id == "regions_3" }.unlocked)
    }

    @Test fun unknownRegionsDoNotCount() =
        assertEquals(0, Achievements.evaluate((1..4).map { stamp(it, null) }).first { it.id == "regions_3" }.progress)

    @Test fun progressNeverExceedsTarget() =
        assertTrue(Achievements.evaluate((1..40).map { stamp(it, "r$it") }).all { it.progress == it.target })
}
