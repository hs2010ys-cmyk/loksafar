package com.loksafar.app

import com.loksafar.app.data.ChatRequest
import com.loksafar.app.data.ChatResponse
import com.loksafar.app.data.DestinationDto
import com.loksafar.app.data.PageDto
import com.loksafar.app.data.RegionDto
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Guards the Android <-> backend contract (field names match app/main.py schemas). */
class DtoParsingTest {
    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }

    @Test fun parsesRegionWithSeasonalCapitals() {
        val r = json.decodeFromString<RegionDto>(
            """{"id":"1","name":"Jammu and Kashmir","slug":"jammu-and-kashmir","administrative_type":"UNION_TERRITORY",
            "verification_status":"PENDING_VERIFICATION","extra":1,
            "capitals":[{"name":"Srinagar","role":"SUMMER_CAPITAL"},{"name":"Jammu","role":"WINTER_CAPITAL"}],
            "languages":[{"language_name":"Kashmiri","iso_639_1":null,"native_name":null}]}"""
        )
        assertEquals("Srinagar (summer capital)", r.capitals.first().display())
        assertEquals("Kashmiri", r.languages.single().name)
    }

    @Test fun parsesDestinationPageWithMissingCoordinates() {
        val p = json.decodeFromString<PageDto<DestinationDto>>(
            """{"items":[{"id":"d1","state_ut_id":"s1","destination_name":"Hampi","verification_status":"PENDING_VERIFICATION",
            "latitude":null,"longitude":null}],"total":1,"page":1,"page_size":100}"""
        )
        assertEquals(1, p.total)
        assertNull(p.items.single().latitude)
    }

    @Test fun parsesDestinationStateId() {
        val d = json.decodeFromString<DestinationDto>("""{"id":"d1","state_ut_id":"s9","destination_name":"Hampi","verification_status":"VERIFIED"}""")
        assertEquals("s9", d.stateUtId)
    }

    @Test fun chatRequestUsesSnakeCaseAndOmitsMissingSession() {
        val body = json.encodeToString(ChatRequest("Namaste", "hi", "historian"))
        assertEquals("""{"message":"Namaste","language":"hi","mode":"historian"}""", body)
    }

    @Test fun parsesChatResponseWithSourcesAndTolerantOfMissingFields() {
        val r = json.decodeFromString<ChatResponse>(
            """{"answer":"A","sources":[{"title":"ASI","url":"https://asi.nic.in"},{"title":"Book"}],"session_id":"abc","unknown":1}"""
        )
        assertEquals(2, r.sources.size)
        assertNull(r.sources[1].url)
        assertNull(r.confidence)
        assertEquals("abc", r.sessionId)
    }
}
