# LOKSAFAR Android (v0.2)

Kotlin · Jetpack Compose · Material 3 · Hilt · Retrofit · kotlinx.serialization · Room · DataStore · Navigation Compose.

## Run
1. Start the backend (`loksafar-backend`): `uvicorn app.main:app --host 0.0.0.0 --port 8000`
2. Open this folder in Android Studio (Koala+), let Gradle sync (if no wrapper jar: `gradle wrapper --gradle-version 8.9`).
3. Run on an emulator. Debug builds call `http://10.0.2.2:8000/`; on a real phone set `API_BASE_URL` in `app/build.gradle.kts` to your PC's LAN IP.
4. Unit tests: `./gradlew testDebugUnitTest`

## Get an APK without installing Android Studio
1. Create a GitHub repository and push the **contents of this folder** (so `build.gradle.kts` is at the repo root).
2. Open the repo's **Actions** tab. The *Build debug APK* workflow runs on every push (or run it manually).
3. When it finishes, download `loksafar-debug-apk` from the run's Artifacts and install the `.apk` on your phone.
4. To point the app at your backend, add a repository variable `API_BASE_URL` (e.g. `http://192.168.1.10:8000/`). Without it the app uses the emulator-only address `10.0.2.2`, so a real phone shows "couldn't load data".
5. If the build fails, the log shows the compile error; paste it back and it can be fixed.

This produces a **debug** APK. A Play Store release needs a signing key and an `https` API URL.

## What is in this build
| Module | State |
|---|---|
| Splash + onboarding (logo, intro, language EN/HI, privacy/permission explanation, guest) | Written |
| Home (categories, recently explored, shortcuts) | Written |
| Explore (36 states/UTs directory, search, region + category pages) | Written (from v0.1) |
| Nearby (device location, manual fallback if denied, straight-line distances) | Written |
| Destination detail (save for offline, share, open in maps, collect passport stamp) | Written |
| Cultural Companion (chat, 3 modes, sources, voice input via system recogniser) | Written; **needs backend `POST /api/v1/ai/chat`** |
| My Journey: saved places, journeys (plan / complete / delete), Heritage Passport + achievements | Written |
| Eco-tourism & responsible-travel guidance | Written |
| Settings (language, theme, privacy text, export data, delete local data) | Written |
| Offline: saved places, last-good regions/categories, offline banner | Written |

## Honest status
* **Nothing here has been compiled with Gradle or run on a device/emulator.** The build environment that produced v0.2 had no Android SDK. The pure logic (distance, stamp checks, achievements, journey ordering) was compiled and run separately with `kotlinc`; those checks pass and are mirrored in `app/src/test/.../LogicTest.kt`. Compose screens, Room, Hilt wiring and the Gradle build are **untested** — expect to fix a few compile errors on first sync.
* **Chat contract is proposed, not verified.** The app sends `{message, language, mode: explorer|historian|storyteller, session_id?}` and expects `{answer, sources:[{title,url?}], confidence?, warnings?, session_id?}`. Adjust `ChatRequest/ChatResponse` in `data/Models.kt` if the backend differs. If the call fails the app says the companion is unavailable; it never invents an answer.
* **Heritage Passport verification is client-side only** (within 500 m, GPS accuracy ≤ 150 m, mock locations rejected). That can be bypassed, so stamps must be re-verified on the server before they count toward certificates or rewards.
* Nearby fetches the first 100 destinations and ranks them on-device. Replace with the backend `/destinations/nearby` once it exists.
* Eco places are found by looking for a category whose slug contains "eco".
* Journey distances are straight-line only. No routing, travel times, opening hours or CultureChain cultural-connection text are generated, because none of that data exists yet.
* Hindi strings need native-speaker review before release.

## Not built yet (needs backend or data first)
Account registration / sign-in, interactive India map (needs a map provider + licence decision), AI-generated CultureChain journeys, Artisan Connect, quizzes and shareable certificates, reviews, push notifications, account deletion on the server, voice output, additional Indian languages, instrumented UI tests.
